package com.example.timeswipe;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class MainPageActivity extends Activity{

	ImageButton goToPieButton;
	ImageButton goToHelpButton;
	public void onCreate(Bundle savedInstanceState){
         super.onCreate(savedInstanceState);
         setContentView(R.layout.main_help_page);
         goToPieButton = (ImageButton)findViewById(R.id.goToPieButton);
         goToPieButtonOnClickListeners();
         goToHelpButton = (ImageButton)findViewById(R.id.goToHelpButton);
         goToHelpButtonOnClickListeners();
    } 
	
	public void goToPieButtonOnClickListeners() {
		goToPieButton.setOnClickListener(new ImageButton.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent myIntent = new Intent(MainPageActivity.this, PieScheduleUI.class);
				MainPageActivity.this.startActivity(myIntent);
			}
		});
	}
	public void goToHelpButtonOnClickListeners() {
		goToHelpButton.setOnClickListener(new ImageButton.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent myIntent = new Intent(MainPageActivity.this, HelpActivity.class);
				MainPageActivity.this.startActivity(myIntent);
			}
		});
	}
}