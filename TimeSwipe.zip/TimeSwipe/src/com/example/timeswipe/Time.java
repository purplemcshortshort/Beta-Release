/**
 * REVISED BSD LICENSE
 * Copyright (c) 2015, Patricia Kelly D. Co, Kenneth T. Otsuka, Mary Jane T. Rubio
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the <organization> nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Patricia Kelly Co, Mary Jane T. Rubio, and 
 * Kenneth T. Otsuka BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT 
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * @author Patricia Kelly D. Co
 * @author Kenneth T. Otsuka
 * This is a course requirement for CS 192 Software Eng'g II under the supervision of 
 * Prof. Ma. Rowena C. Solamo of the Department of Computer Science, College of Engineering, 
 * University of the Philippines, Diliman for AY 2014-2015.
 */
/**
 * Code History
 * @version 1.0
 * @author Mary Jane T. Rubio
 * @since 2015-02-16
 * Initial code.
 * 
 */
/**
 * Created on 2015-02-16
 * Developed by Purple McShortShort
 * Client Pink PlastiCS
 * Models a time
 */

package com.example.timeswipe;

/**
 * Contains the hour, minute and second.
 */
public class Time {
     int hour;
     int minute;
     int second;
     /**
      * Time 
	  *  - constructor
      * @since 2015-02-16
      * @param void
      * @return void
      */
     public Time(){
    	 hour = -1;
    	 minute = -1;
    	 second = -1;
     }
     /**
      * Time 
      *  - constructor. Sets the hour, minute and second.
      * @since 2015-02-16
      * @param h The time's hour (int)
      * @param m The time's minute (int)
      * @param s The time's second (int)
      * @return void
      */
     public Time(int h, int m, int s){
          hour = h;
          minute = m;
          second = s;
     }
     /**
      * Time 
      *  - constructor. Sets the hour, minute and second from a String.
      * @since 2015-02-16
      * @param s The time (String)
      * @return void
      */
     public Time(String s){
          String[] time = s.split(":");
          hour = Integer.parseInt(time[0]);
          minute = Integer.parseInt(time[1]);
          second = Integer.parseInt(time[2]);
     }
     /**
      * Time 
      *  - constructor. Sets the hour, minute and second from total seconds
      * @since 2015-02-16
      * @param s The time in seconds (long)
      * @return void
      */
     public Time(long s){
    	 //System.out.println(s);
    	 if(s<0){
    		 s = 86400+s;
    	 }
    	 hour = (int)(s/3600);
    	 s = s%3600;
    	 minute = (int)(s/60);
    	 second = (int)(s%60);
     }
     /**
      * setTime
      *  - sets the hour, minute and second
      * @since 2015-02-16
      * @param h The hour (int)
      * @param m The minute (int)
      * @param s The second (int)
      * @return void
      */
     public void setTime(int h, int m, int s){
          hour = h;
          minute = m;
          second = s;
     }
     /**
      * setHour
      *  - sets the hour
      * @since 2015-02-16
      * @param h The time's hour (int)
      * @return void
      */
     public void setHour(int h){
          hour = h;
     }
     /**
      * setMinute
      *  - sets the minute
      * @since 2015-02-16
      * @param m The time's minute (int)
      * @return void
      */
     public void setMinute(int m){
          minute = m;	 
     }
     /**
      * setSecond
      *  - sets the second
      * @since 2015-02-16
      * @param s The time's second (int)
      * @return void
      */
     public void setSecond(int s){
          second = s;	 
     }
     /**
      * getHour
      *  - returns the time's hour
      * @since 2015-02-16
      * @return the time's hour (int)
      */
     public int getHour(){
          return hour;	 
     }
     /**
      * getMinute
      *  - returns the time's minute
      * @since 2015-02-16
      * @return the time's minute (int)
      */
     public int getMinute(){
          return minute;
     }
     /**
      * getSecond
      *  - returns the time's second
      * @since 2015-02-16
      * @return the time's minute (int)
      */
     public int getSecond(){
          return second;
     }
     /**
      * totalInMilliSec
      *  - returns the time's total in milliseconds
      * @since 2015-02-16
      * @return the time's total in milliseconds (long)
      */
     public long totalInMilliSec(){
          return 1000*totalInSec();
     }
     /**
      * getTotalInSec
      *  - returns the time's total in seconds
      * @since 2015-02-16
      * @return the time's total in seconds (long)
      */
     public long totalInSec(){
          return ((hour * 3600) + (minute * 60) + second);
     }
     
     public void minusOneSec(){
    	 if(second>0){
    		 second--;
    	 }
    	 else if(minute>0){
    		 minute--;
    		 second = 59;
    	 }
    	 else if(hour>0){
    		 hour--;
    		 minute = 59;
    		 second = 59;
    	 }
     }
     
     /**
      * toString
      *  - returns the time in hh:mm:ss format
      * @since 2015-02-16
      * @return the time (String)
      */
     @Override
     public String toString(){
    	  String strHour, strMin, strSec;
    	  strHour = Integer.toString(hour);
    	  strMin = Integer.toString(minute);
    	  strSec = Integer.toString(second);
    	  if(!strHour.equals("-1")){
	    	  if(strHour.length() == 1){
	    		  strHour = "0"+strHour;
	    	  }
	    	  if(strMin.length() == 1){
	    		  strMin = "0"+strMin;
	    	  }
	    	  if(strSec.length() == 1){
	    		  strSec = "0"+strSec;
	    	  }
    	  }
    	  return strHour+":"+strMin+":"+strSec;   
     }
     
}