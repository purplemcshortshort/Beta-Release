/**
 * REVISED BSD LICENSE
 * Copyright (c) 2015, Patricia Kelly D. Co, Kenneth T. Otsuka, Mary Jane T. Rubio
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the <organization> nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Patricia Kelly Co, Mary Jane T. Rubio, and 
 * Kenneth T. Otsuka BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT 
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * @author Mary Jane T. Rubio
 * This is a course requirement for CS 192 Software Eng'g II under the supervision of 
 * Prof. Ma. Rowena C. Solamo of the Department of Computer Science, College of Engineering, 
 * University of the Philippines, Diliman for AY 2014-2015.
 */
/**
 * Code History
 * @version 1.0
 * @author Mary Jane T. Rubio
 * @since 2014-11-20
 * Initial code.
 */
/**
 * Created on 2014-11-20
 * Developed by Purple McShortShort
 * Client Pink PlastiCS
 * Model of a slice in a PieSchedule.
 */

package com.example.timeswipe;

/**
 *Stores a slice's angles, color, duration and task.
 */
public class Slice{
     private float startAngle;
     private float sweepAngle;
     private int color;
     private Time remTime;
     private Task task;
     
     /**
      * Slice
      *  - Slice constructor. Sets attributes of a slice.
      * @since 2014-11-20
      * @param sta Slice start angle (float)
      * @param swa Slice sweep angle (float)
      * @param c Slice color (int)
      * @param rt Slice remaining time (Time)
      * @param t Slice task name (Task)
      * @return void
      */
     public Slice(float sta, float swa, int c, Time rt, Task t){
          startAngle = sta;
          sweepAngle = swa;
          color = c;
          remTime = rt;
          task = t;
     }
     
     public Slice(float sta, float swa, int c, Task t){
         startAngle = sta;
         sweepAngle = swa;
         color = c;
         task = t;
    }
     public Slice(int c, Task t){
         color = c;
         task = t;
    }
     
     /**
      * getStart
      *  - Returns the starting angle of a slice.
      * @since 2014-11-20
      * @param void
      * @return startAngle
      */
     public float getStartAngle(){
          return startAngle;
     }
     
     /**
      * getSweepAngle
      *  - Returns the sweep angle of a slice.
      * @since 2014-11-20
      * @param void
      * @return sweepAngle
      */
     public float getSweepAngle(){
          return sweepAngle;
     }
     
     /**
      * getColor
      *  - Returns the color of a slice.
      * @since 2014-11-20
      * @param void
      * @return color
      */
     public int getColor(){
          return color;
     }
     
     /**
      * getRemTime
      *  - Returns the remaining time of a slice.
      * @since 2014-11-20
      * @param void
      * @return remTime
      */
     public Time getRemTime(){
          return remTime;
     }
     
     /**
      * getTask
      *  - Returns the task name of a slice.
      * @since 2014-11-20
      * @param void
      * @return task
      */
     public Task getTask(){
          return task;
     }
     
     /**
      * setStartAngle
      *  - Sets start angle of a slice.
      * @since 2014-11-20
      * @param sta Start angle (float)
      * @return void
      */
     public void setStartAngle(float sta){
          startAngle = sta;
     }
     
     /**
      * setSweepAngle
      *  - Sets the sweep angle of a slice.
      * @since 2014-11-20
      * @param swa Sweep angle (float)
      * @return void
      */
     public void setSweepAngle(float swa){
          sweepAngle = swa;
     }
     
     /**
      * setRemTime
      *  - Sets the remaining time of a slice.
      * @since 2014-11-20
      * @param rt Remaining time (Time)
      * @return void
      */
     public void setRemTime(Time rt){
          remTime = rt;
     }
}