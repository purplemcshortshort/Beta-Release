/**
 * REVISED BSD LICENSE
 * Copyright (c) 2015, Patricia Kelly D. Co, Kenneth T. Otsuka, Mary Jane T. Rubio
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the <organization> nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Patricia Kelly Co, Mary Jane T. Rubio, and 
 * Kenneth T. Otsuka BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT 
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * @author Mary Jane T. Rubio
 * This is a course requirement for CS 192 Software Eng'g II under the supervision of 
 * Prof. Ma. Rowena C. Solamo of the Department of Computer Science, College of Engineering, 
 * University of the Philippines, Diliman for AY 2014-2015.
 */
/**
 * Code History
 * @version 1.0
 * @author Mary Jane T. Rubio
 * @since 2015-11-20
 * Initial code.
 * @version 1.1
 * @author Mary Jane T. Rubio
 * @since 2015-02-10
 * Changed initPieSchedule(), returns a PieSchedule instead of void
 * Added method save(PieSchedule);
 * @version 1.2
 * @author Mary Jane T. Rubio
 * @since 2015-02-16
 * Changed the times' data type from String to Time and long.
 */
/**
 * Created on 2014-11-20
 * Developed by Purple McShortShort
 * Client Pink PlastiCS
 * The controller for the application's boundary, object and DAO classes.
 */
package com.example.timeswipe;

import java.util.Arrays;

import android.graphics.Color;

/**
 * Contains methods that connects the boundary, object, and DAO classes for the PieSchedule.
 *
 */
public class PieScheduleController {
	
	public static Task tempTask;
     /**
      * initPieSchedule
      *  - Creates the saved PieSchedule
      * @since 2014-11-20
      * @param void
      * @return the PieSchedule to be initialized
      */
     public static PieSchedule initPieSchedule(){
          return PieScheduleDao.read();
     }
     
     /**
      * reset
      *  - Sets all the times to 00:00:00 and deletes all the slices. Calls PieScheduleDao.write(PieSchedule) to save its state.
      * @since 2014-11-20
      * @param ps The PieSchedule to be reset (PieSchedule)
      * @return void
      */
     public static void reset(PieSchedule ps){
          ps.setStartTime(new Time(-1,-1,-1));
          ps.setEndTime(new Time(-1,-1,-1));
          ps.setRemTime(new Time(-1,-1,-1));
          while(ps.getSize()>0)
               ps.deleteSlice(0);
          PieScheduleDao.write(ps);
     }
     
     /**
      * save
      *  - saves the PieSchedule to source file
      * @since 2015-02-16
      * @param ps The PieSchedule (PieSchedule)
      * @return void
      */
     public static void save(PieSchedule ps){
          PieScheduleDao.write(ps);
     }

	public static void addTask(PieSchedule ps, int color) {
		int numSlices = ps.getSize()+1;
		long psDuration = ps.getRemTime().totalInSec();
		float sweepAngle = 360/numSlices;
		if(psDuration > 0 ){
			long seconds = psDuration/numSlices;
			int i = 0;
			for(;i<numSlices-1;i++){
				Slice s = ps.getSlice(i);
				s.setStartAngle(-90+i*sweepAngle);
				s.setSweepAngle(sweepAngle);
				s.setRemTime(new Time(seconds));
			}
			ps.addSlice(new Slice(-90+i*sweepAngle, 360-sweepAngle*(numSlices-1), color, new Time(psDuration - seconds*(numSlices-1)), tempTask));
		}
		else{
			int i = 0;
			for(;i<numSlices-1;i++){
				Slice s = ps.getSlice(i);
				s.setStartAngle(-90+i*sweepAngle);
				s.setSweepAngle(sweepAngle);
			}
			ps.addSlice(new Slice(-90 + i*sweepAngle,  360-sweepAngle*(numSlices-1), color, new Time(),tempTask));
		}
		PieScheduleDao.write(ps);
	}
}