/**
 * REVISED BSD LICENSE
 * Copyright (c) 2015, Patricia Kelly D. Co, Kenneth T. Otsuka, Mary Jane T. Rubio
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the <organization> nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Patricia Kelly Co, Mary Jane T. Rubio, and 
 * Kenneth T. Otsuka BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT 
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * @author Patricia Kelly D. Co
 * @author Kenneth T. Otsuka
 * This is a course requirement for CS 192 Software Eng'g II under the supervision of 
 * Prof. Ma. Rowena C. Solamo of the Department of Computer Science, College of Engineering, 
 * University of the Philippines, Diliman for AY 2014-2015.
 */
/**
 * Code History
 * @version 1.0
 * @author Patricia Kelly D. Co
 * @since 2014-11-13
 * Initial code.
 * @version 1.1
 * @author Kenneth T. Otsuka
 * @since 2014-02-06
 * Added Set Time functionality.
 * @author Patricia Kelly D. Co
 * @since 2014-02-10
 * Changed Button setTimeButton, startButton, and resetButton to ImageButton.
 * Added an onClickListener for startButton. 
 * Changed the layout design.
 */
/**
 * Created on 2014-11-13
 * Developed by Purple McShortShort
 * Client Pink PlastiCS
 * The Boundary Class of the application.
 */

package com.example.timeswipe;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import android.support.v4.app.Fragment;
/**
 * Handles the displaying of all UI.  
 *
 */

public class PieScheduleUI extends Fragment {
	
	private boolean[] isColorTaken;
	private Button addButton;
    private Chronometer chronometer;
    private int[] colors;
    private EditText inputText;
    //private CountDownTimer countDown;
    private ImageButton resetButton;
    private ImageButton setTimeButton;
    private ImageButton startButton;
    private PieSchedule pieSchedule;
    private PieUI pie;
    private SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
    private TimePicker timePicker;
    
    private Context context;    
  
    public PieScheduleUI(Context c) {
        this.context = c;
    }
    
    
    /**
     * onCreate
     *  - This is the onCreate method that starts up the TimePies.
     * @since 2015-02-10
     * @param savedInstanceState Saves the state upon call
     * @return void
     * @exception InterruptedException
     */
    
    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.activity_pie_ui, container, false);
        PieScheduleDao.context = this.getActivity().getApplicationContext();
        /* init pie schedule, create from source file*/
        pieSchedule = PieScheduleController.initPieSchedule();
        /* init the time displayed */
        chronometer = (Chronometer) view.findViewById(R.id.chronometer);
        long timeRem = pieSchedule.getRemTime().totalInMilliSec();
        if(timeRem >= 0)
        	chronometer.setText("" + timeFormat.format(timeRem)); 
        else
        	chronometer.setText("" + timeFormat.format(0));
        /* init button click listeners */
        addButton = (Button) view.findViewById(R.id.addButton);
        setAddButtonOnClickListeners();
        setTimeButton = (ImageButton) view.findViewById(R.id.setTimeButton);
        setTimeButtonOnClickListeners();
        startButton = (ImageButton) view.findViewById(R.id.startButton);
        startButtonOnClickListeners();
        resetButton = (ImageButton)view.findViewById(R.id.resetButton);
        resetButtonOnClickListeners();
        /* init the displayed pie */
        pie = (PieUI) view.findViewById(R.id.pie);
        pie.draw(pieSchedule);
        /* init available colors */
        initColors();
        
        
        return view;
     }
    
    private void resetButtonOnClickListeners(){
		resetButton.setOnClickListener(new Button.OnClickListener(){
			@Override
        	public void onClick(View v) {
				if(pieSchedule.isEmpty()){
					Toast.makeText(getActivity().getApplicationContext(), "Pie is empty.", Toast.LENGTH_SHORT).show();
 	                return;
				}
        		AlertDialog.Builder builder1 = new AlertDialog.Builder(v.getContext());
        		builder1.setMessage("Are you sure you want to reset the entire schedule?");
        		builder1.setCancelable(true);
        		
        		builder1.setPositiveButton("Yes",
        				new DialogInterface.OnClickListener() {
        			public void onClick(DialogInterface dialog, int id) {
        				PieScheduleController.reset(pieSchedule);
        				pie.draw(pieSchedule);
        				initColors();
        				chronometer.setText("" + timeFormat.format(0));
        			}
        		});
        		
        		builder1.setNegativeButton("No",
        				new DialogInterface.OnClickListener() {
        			public void onClick(DialogInterface dialog, int id) {
        				dialog.cancel();
        			}
        		});
        		
        		AlertDialog alert11 = builder1.create();
                alert11.show();
        	}
       	});
    }

	private void setAddButtonOnClickListeners(){
		addButton.setOnClickListener(new Button.OnClickListener(){
			@Override
        	public void onClick(View v) {
				if(pieSchedule.getSize() == 10){
					Toast.makeText(getActivity().getApplicationContext(), "You have reached the maximum number of tasks!", Toast.LENGTH_SHORT).show();
 	                return;
				}
        		AlertDialog.Builder builder1 = new AlertDialog.Builder(v.getContext());
        		inputText = new EditText(v.getContext());
        		builder1.setMessage("New task:");
        		builder1.setView(inputText);
        		
        		builder1.setCancelable(true);
        		builder1.setPositiveButton("Okay",
        				new DialogInterface.OnClickListener() {
        			public void onClick(DialogInterface dialog, int id) {
        			}
        		});
        		
        		builder1.setNegativeButton("Cancel",
        				new DialogInterface.OnClickListener() {
        			public void onClick(DialogInterface dialog, int id) {
        				dialog.cancel();
        			}
        		});
        		
        		final AlertDialog alert = builder1.create();
        		alert.show(); 
        		
        		alert.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener()
        	      {            
        	          @Override
        	          public void onClick(View v)
        	          {
        	              /* Do stuff, possibly set wantToCloseDialog to true then... */
        					setAddButtonOnClickListeners();
        					String strTask = inputText.getText().toString();
        					if (!strTask.equals("")){
        						PieScheduleController.tempTask = new Task(strTask);
        						chooseColor();
        						alert.dismiss();
        					}
        					else
        						Toast.makeText(getActivity().getApplicationContext(), "Please enter task", Toast.LENGTH_SHORT).show();
        	          }
        	      });
        	}
       	});
    }

	/**
     * startButtonOnClickListeners
     *  - Called when startButton is clicked. Starts the count down timer.
     * @since 2015-02-10
     * @return void
     * @param void 
     */
    private void startButtonOnClickListeners(){
         startButton.setOnClickListener(new ImageButton.OnClickListener(){
            @Override
              public void onClick(View view){
                   if(pieSchedule.isReadyToStart()){
                        //countDownToZero();
                        //startCountDownToZero();
                   } 
              }    
         });
    }
    
    private void initColors(){
    	int numColors = 12;
    	colors = new int[numColors];

    	colors[0] = Color.parseColor("#DBFF76"); 
    	colors[1] = Color.parseColor("#CFFFB0");
    	colors[2] = Color.parseColor("#C3D898");
        colors[3] = Color.parseColor("#4E7144"); 

    	colors[4] = Color.parseColor("#F79F79");
    	colors[5] = Color.parseColor("#C4E7D4");

    	colors[6] = Color.parseColor("#177E89");

    	colors[7] = Color.parseColor("#08605F");
    	colors[8] = Color.parseColor("#E99B9B");
    	colors[9] = Color.parseColor("#D0939F");
    	colors[10] = Color.parseColor("#B9C0DA");
    	colors[11] = Color.parseColor("#ABA5DA");
    	
    	isColorTaken = new boolean[numColors];
    	Arrays.fill(isColorTaken, false);
    	
    	int numSlices = pieSchedule.getSize();
    	for(int i = 0; i< numSlices; i++){
    		markColorTaken(pieSchedule.getSlice(i).getColor());
    	}
    }
    
    private void markColorTaken(int color){
    	for(int i = 0; i<colors.length; i++){
    		if(colors[i] == color){
    			isColorTaken[i] = true;
    			break;
    		}
    	}
    }
    
	private void chooseColor() {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
	
        // Prepare grid view
        GridView gridView = new GridView(context);
        
        List<String> mList = new ArrayList<String>();
        final int numColors = 12;
        for(int i = 0; i<numColors; i++){
        	if(isColorTaken[i])
        		mList.add("X");
        	else
        		mList.add("");
        }
        
        gridView.setAdapter(new ArrayAdapter(context, android.R.layout.simple_list_item_1, mList) {
        	@Override
        	public View getView(int position, View convertView, ViewGroup parent) {
        	    View view = super.getView(position, convertView, parent);
        	    for(int i = 0; i< numColors; i++){
        	    	view.setBackgroundColor(colors[position]);
        	    }
        	    return view;
        	  }
        });
        
        gridView.setNumColumns(4);
        
        // Set grid view to alertDialog
        builder.setView(gridView);
        builder.setTitle("Choose color: ");
        
        final  AlertDialog alert = builder.create();
        alert.show();
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {		        	
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            	if(isColorTaken[position]){
            		Toast.makeText(context, "Choose a different color!", Toast.LENGTH_SHORT).show();
            	}else{
	            	markColorTaken(colors[position]);
	            	PieScheduleController.addTask(pieSchedule, colors[position]);
					pie.draw(pieSchedule);
	          		alert.dismiss();
            	}
            }    
        });
    }
    
    /**
     * setTimeButtonOnClickListeners
     *  - Called when setTimeButton has been clicked. Lets user choose between
     *    setting start-end time or setting duration.
     * @since 2015-02-06
     * @param void
     * @return void
     */
    private void setTimeButtonOnClickListeners(){
         setTimeButton.setOnClickListener(new ImageButton.OnClickListener(){
            @Override
              public void onClick(View view){    
                   final CharSequence[] timeChoice = {" Set Start-End Time "," Set Duration "};
//                   AlertDialog.Builder builder = new AlertDialog.Builder(context);
                   AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                    builder.setTitle("Choose type on time input:");
                   builder.setItems(timeChoice, new DialogInterface.OnClickListener(){
                      @Override
                        public void onClick(DialogInterface dialog, int item){
                             switch(item){
                             case 0:
                                  /* Set Start and End Time is selected */
                                  dialog.dismiss();
                                  setStartTime();
                                  break;
                             case 1:
                                  /* Duration is selected */
                                  dialog.dismiss();
                                  setDuration();
                                  break;
                             }
                             dialog.dismiss();
                        }
                   });
                   AlertDialog alert = builder.create();
                   alert.show();
              }
         });
    }
    
    /**
     * setStartTime
     *  - Set the start time of your Pie Schedule. Automatically calls {@link #setEndTime()}.
     * @since 2015-02-06
     * @param void
     * @return void
     */
    public void setStartTime(){
//    	AlertDialog.Builder builder = new AlertDialog.Builder(context);
         AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
         builder.setTitle("Set Time Start:");
//         timePicker = new TimePicker(context);
         timePicker = new TimePicker(view.getContext());
         timePicker.setIs24HourView(true);
         timePicker.setCurrentHour(0);
         timePicker.setCurrentMinute(0);
         builder.setView(timePicker);
         builder.setPositiveButton("Okay", new DialogInterface.OnClickListener(){
            @Override
              public void onClick(DialogInterface dialog, int id){
                   pieSchedule.setStartTime(new Time(timePicker.getCurrentHour(), timePicker.getCurrentMinute(), 0));
                   dialog.cancel();
                   setEndTime();
              }
         });
         builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener(){
            @Override
              public void onClick(DialogInterface dialog, int id){
                   dialog.cancel();
              }
         });
         AlertDialog alert = builder.create();
         alert.show();
    }
    
    /**
     * setEndTime
     *  - Set the end time of your Pie Schedule.
     * @since 2015-02-06
     * @param void
     * @return void
     */
    public void setEndTime(){
//    	AlertDialog.Builder builder = new AlertDialog.Builder(context);
    	AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
         builder.setTitle("Set Time End:");
//         timePicker = new TimePicker(context);
         timePicker = new TimePicker(view.getContext());
         timePicker.setIs24HourView(true);
         timePicker.setCurrentHour(0);
         timePicker.setCurrentMinute(0);
         builder.setView(timePicker);
         builder.setPositiveButton("Okay", new DialogInterface.OnClickListener(){
            @Override
              public void onClick(DialogInterface dialog, int id){
                 pieSchedule.setEndTime(new Time(timePicker.getCurrentHour(), timePicker.getCurrentMinute(), 0));
                 pieSchedule.setRemTime();
                   chronometer.setText("" + timeFormat.format(pieSchedule.getRemTime().totalInMilliSec()));
                   PieScheduleController.save(pieSchedule);
                   dialog.cancel();
              }
         });
         builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener(){
            @Override
              public void onClick(DialogInterface dialog, int id){
                 pieSchedule.setStartTime(new Time(-1,-1,-1));
                   dialog.cancel();
              }
         });
         AlertDialog alert = builder.create();
         alert.show();
    }
    
    /**
     * setDuration
     *  - Set the time duration of your Pie Schedule.
     * @since 2015-02-06
     * @param void
     * @return void
     */
    public void setDuration(){
//    	AlertDialog.Builder builder = new AlertDialog.Builder(context);
    	AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
        builder.setTitle("Set Duration:");
//        timePicker = new TimePicker(context);
        timePicker = new TimePicker(view.getContext());
         timePicker.setIs24HourView(true);
         timePicker.setCurrentHour(0);
         timePicker.setCurrentMinute(0);
         builder.setView(timePicker);
         builder.setPositiveButton("Okay", new DialogInterface.OnClickListener(){
            @Override
              public void onClick(DialogInterface dialog, int id){
                   pieSchedule.setStartTime(new Time(-1,-1,-1));
                 pieSchedule.setEndTime(new Time(-1,-1,-1));
                   pieSchedule.setRemTime(new Time(timePicker.getCurrentHour(), timePicker.getCurrentMinute(), 0));
                   chronometer.setText("" + timeFormat.format(pieSchedule.getRemTime().totalInMilliSec()));
                   PieScheduleController.save(pieSchedule);
                   dialog.cancel();
              }
         });
         builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener(){
            @Override
              public void onClick(DialogInterface dialog, int id){
                   dialog.cancel();
              }
         });
         AlertDialog alert = builder.create();
         alert.show();
    }
    
    /**
     * countDownToZero
     *  - Sets the text of the Chronometer into the duration of the Pie Schedule.
     * @since 2015-02-06
     * @param void
     * @return void
     */
/*     private void countDownToZero(){
         chronometer = (Chronometer) findViewById(R.id.chronometer);
         Toast.makeText(getApplicationContext(), Long.toString(computeRemainingTime()/1000) + " seconds", Toast.LENGTH_SHORT).show();
         countDown = new CountDownTimer(computeRemainingTime(), 1000){
              public void onTick(long millisUntilFinished) {
                   chronometer.setText("" + timeFormat.format(millisUntilFinished));
              }
              public void onFinish(){
                   chronometer.setText("Time's up!");
              }
         };
    }
*/     
    /**
     * startCountDownToZero
     *  - Starts the countdown timer.
     * @since 2015-02-06
     * @param void
     * @return void
     */
/*     private void startCountDownToZero(){
         countDown.start(); 
    }
*/ 
}

