/**
 * REVISED BSD LICENSE
 * Copyright (c) 2015, Patricia Kelly D. Co, Kenneth T. Otsuka, Mary Jane T. Rubio
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the <organization> nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Patricia Kelly Co, Mary Jane T. Rubio, and 
 * Kenneth T. Otsuka BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT 
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * @author Mary Jane T. Rubio
 * This is a course requirement for CS 192 Software Eng'g II under the supervision of 
 * Prof. Ma. Rowena C. Solamo of the Department of Computer Science, College of Engineering, 
 * University of the Philippines, Diliman for AY 2014-2015.
 */
/**
 * Code History
 * @version 1.0
 * @author Mary Jane T. Rubio
 * @since 2014-11-20
 * Initial code.
 * @version 1.1
 * @author Mary Jane T. Rubio
 * @since 2015-02-16
 * Changed the data type of the attributes start, end, duration, as well as the methods associated to them,from String to Time.
 */
/**
 * Created on 2014-11-20
 * Developed by Purple McShortShort
 * Client Pink PlastiCS
 * Model of a PieSchedule.
 */

package com.example.timeswipe;

import java.util.*;

/**
 * Stores the PieSchedule's time and slices/tasks. 
 *
 */
public class PieSchedule{
     /*private String startTime;
     private String endTime;
     private String remTime;*/
	 private boolean empty;
	 private boolean readyToStart;
	 private boolean running;
	 private Time startTime;
	 private Time endTime;
	 private Time remTime;
     private ArrayList<Slice> slices;
     
     /**
      * PieSchedule
      *  - PieSchedule constructor. Creates the task slice.
      * @since 2014-11-20
      * @param void
      * @return void
      */
     public PieSchedule(){
          slices = new ArrayList<Slice>();
          empty = true;
          readyToStart = false;
          running = false;
          startTime = new Time(-1,-1,-1);
          endTime = new Time(-1,-1,-1);
          remTime = new Time(-1,-1,-1);
     }
     
     /**
      * getStartTime
      *  - Returns the starting time.
      * @since 2015-02-16
      * @param void
      * @return startTime
      */
     public Time getStartTime(){
          return startTime;
     }
     
     /**
      * getEndTime
      *  - Returns the ending time.
      * @since 2015-02-16
      * @param void
      * @return endTime
      */
     public Time getEndTime(){
          return endTime;
     }
     
     /**
      * getRemTime
      *  - Returns the remaining time.
      * @since 2014-11-20
      * @param void
      * @return remTime
      */
     public Time getRemTime(){
          return remTime;
     }
     
     /**
      * getSlice
      *  - Returns a task slice.
      * @since 2014-11-20
      * @param i Index of slice (int)
      * @return slices.get(i) A slice in the array
      */
     public Slice getSlice(int i){
          return slices.get(i);
     }
     
     public ArrayList<Slice> getSlices(){
    	 return slices;
     }
     
     /**
      * addSlice
      *  - Adds a task slice.
      * @since 2014-11-20
      * @param s A task slice (Slice)
      * @return void
      */
     public void addSlice(Slice s){
          slices.add(s);
          if(empty)
               empty = false;
          if(remTime.totalInSec() > 0)
        	   readyToStart = true;
     }
     
     /**
      * setStartTime
      *  - Sets the starting time.
      * @since 2014-11-20
      * @param st Starting time (Time)
      * @return void
      */
     public void setStartTime(Time st){
          this.startTime = st;
     }
     
     /**
      * setEndTime
      *  - Sets the end time.
      * @since 2015-02-16
      * @param et End time (Time)
      * @return void
      */
     public void setEndTime(Time et){
          endTime = et;
     }
     
     /**
      * setRemTime
      *  - Sets the remaining time left. 
      * @since 2015-02-16
      * @param rt Remaining time left (Time)
      * @return void
      */
     public void setRemTime(Time rt){
          remTime = rt;
          if(empty)
               empty = false;
          if(rt.totalInSec() <= 0 && slices.isEmpty()){
               empty = true;
          	   readyToStart = false;
          	   running = false;
          }
          if(!slices.isEmpty() && rt.totalInSec() > 0) 
        	   readyToStart = true;
     }
     /**
      * setRemTime
      *  - Sets the remaining time left computed from start and end times. 
      * @since 2015-02-16
      * @param void
      * @return void
      */
     public void setRemTime(){
          remTime = new Time(endTime.totalInSec() - startTime.totalInSec());
          if(empty)
               empty = false;
          if(remTime.totalInSec() <= 0 && slices.isEmpty()){
               empty = true;
          	   readyToStart = false;
          	   running = false;
          }
          if(!slices.isEmpty() && remTime.totalInSec() > 0) 
        	   readyToStart = true;
     }
     
     /**
      * getSize
      *  - Returns the number of slices.
      * @since 2014-11-20
      * @param void
      * @return slices.size()
      */
     public int getSize(){
          return slices.size();
     }
     
     /**
      * deleteSlice
      *  - Deletes a slice.
      * @since 2014-11-20
      * @param i Index of slice (int)
      * @return void
      */
     public void deleteSlice(int i){
          slices.remove(i);
          if(slices.isEmpty() && remTime.totalInSec() <= 0){
        	  empty = true;
              readyToStart = false;
              running = false;
          }
     }
     /**
      * isEmpty
      *  - returns if PieSchedule is totally empty
      * @since 2015-02-17
      * @param void
      * @return true if empty
      * @return false if has time or tasks
      */
     public boolean isEmpty(){
    	  return empty;
     }
     /**
      * isReadyToStart
      *  - returns if PieSchedule has tasks and time before it starts
      * @since 2015-02-17
      * @param void
      * @return true if can be started
      * @return false if time has not been set or has no task to be done
      */
     public boolean isReadyToStart(){
    	  return readyToStart;
     }
     /**
      * isRunning
      *  - returns if PieSchedule is running
      * @since 2015-02-17
      * @param void
      * @return true if running
      * @return false otherwise
      */
     public boolean isRunning(){
          return running;
     }
     /**
      * setRunning
      *  - sets running to true or false
      * @since 2015-02-17
      * @param r (boolean)
      * @return void
      */
     public void setRunning(boolean r){
    	 running = r;
     }
}